﻿using DataGridPerson.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace DataGridPerson.Persistance
{
    class PersonManage
    {
        private DataGrid dataGrid = new DataGrid();
        private List<Person> listPerson;
    }
}
